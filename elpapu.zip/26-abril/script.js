
function submitPokemon(){
    const pokemonTable = document.getElementById("pokemonTable");
    const name = document.getElementById("opa");
    const tipo1 = document.getElementById("gangam");
    const tipo2 = document.getElementById("style");
    const inputValues = [ name, tipo1, tipo2 ];

    const container = document.createElement("tr");
    pokemonTable.append(container)
    
    inputValues.forEach((inputField) => {
        const field = document.createElement("td");
        field.innerHTML = inputField.value;
        container.append(field);
    });

    inputValues.forEach((inputField) => {
        inputField.innerHTML = "";
        inputField.value = "";
    });

}

    function mostrarElementos(){
        var x = document.getElementById("esconder");
        if(x.style.value === "none"){
            x.style.value = block;
        }
        else {
            x.style.display = none;
        }
    }
    
